import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featured-courses',
  templateUrl: './featured-courses.component.html',
  styleUrls: ['./featured-courses.component.css']
})
export class FeaturedCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
