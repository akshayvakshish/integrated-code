export class Lead{
    public name:String;
    public isStudent:String;
    public companyName:String;
    public mobile:String;
    public email:String;
}