export class CourseTemplate {
      public courseTitle: string;
      public courseHeader: string;
      public courseHeaderContent: string;
      public courseBody: string;
      public courseFooter: string;
}
